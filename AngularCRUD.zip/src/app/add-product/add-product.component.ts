import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';
import { Router } from "@angular/router";

import { ProductService } from '../product.service';
import { ProductModel } from '../ProductModel';
import { FormsModule } from '@angular/forms';

const URL = 'http://localhost:3000/api/upload';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})

export class AddProductComponent implements OnInit {


  public uploader: FileUploader = new FileUploader({url: URL, itemAlias: 'photo'});
  localUrl: any[];
  product: ProductModel;
  imageload = 'no';
  submitted = false;
  uploadedImage = '';

  constructor(private router: Router,
              private productService: ProductService) { }


  showImage(event: any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.localUrl = event.target.result;
      }
      reader.readAsDataURL(event.target.files[0]);
      this.imageload = 'yes';
      console.log(this.localUrl);
    }
    this.uploader.uploadAll();

  }

  ngOnInit() {
    this.product = {
      _id: '',
      title: '',
      description: '',
      image: ''
    }

    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      var res = JSON.parse(response);
      this.uploadedImage = res.uploadedName;
    };

  }

  onSubmit() {
    this.submitted = true;

    this.product.image = this.uploadedImage;


    this.productService.addProduct(this.product)
      .subscribe( data => {
        console.log(data);
        this.router.navigate(['products']);
      });

  }


}
