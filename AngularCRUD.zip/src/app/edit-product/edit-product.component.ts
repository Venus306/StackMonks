import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';
import { Router } from "@angular/router";

import { ProductService } from '../product.service';
import { ProductModel } from '../ProductModel';
import { FormsModule } from '@angular/forms';

const URL = 'http://localhost:3000/api/upload';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})

export class EditProductComponent implements OnInit {

  public uploader: FileUploader = new FileUploader({url: URL, itemAlias: 'photo'});
  localUrl: any[];
  product: ProductModel;
  submitted = false;
  uploadedImage = '';
  imageload = 'no';

  constructor(private router: Router,
              private productService: ProductService) { }



  showImage(event: any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.localUrl = event.target.result;
      }
      reader.readAsDataURL(event.target.files[0]);
      this.imageload = 'yes';
      console.log(this.localUrl);
    }
    this.uploader.uploadAll();


  }

  ngOnInit() {
    let productId = localStorage.getItem("productId");
    if (!productId) {
      alert("Something wrong!");
      this.router.navigate(['products']);
      return;
    }

    this.productService.getProductById(productId).subscribe( data => {
      console.log(data);
      this.product = data;
    });

    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      var res = JSON.parse(response);
      this.uploadedImage = res.uploadedName;
    };

  }


  onSubmit(){
    this.submitted = true;
    if (this.imageload == 'yes')
      this.product.image = this.uploadedImage;

    this.productService.updateProduct(this.product)
    .subscribe( data => {
      console.log(data);
      this.router.navigate(['products']);
    });

  }


}
