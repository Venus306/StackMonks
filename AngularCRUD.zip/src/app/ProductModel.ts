export class ProductModel {
  _id: string;
  title: String;
  description: String;
  image: String;
}
